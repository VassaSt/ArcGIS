reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  :root {
    --brand-blue-main: #3B3CD0;
    --color-secondary-main: #4D5358;
    --color-secondary-weak: #343A3F;
    --neutral-color-palette-3: #F5F5F5;
    --color-outline-weakest: rgba(0, 0, 0, 0.25);
    --color-content-with-background: #FFFFFF;
  }

  html,
  body {
    margin: 0;
    width: 312px;
  }

  #wrapper {
    position: relative;
    box-sizing: border-box;
    display: flex;
    flex-wrap: nowrap;
    padding: 12px;
    flex-direction: column;
    border-radius: 4px;
    background: var(--neutral-color-palette-3);
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  ._open {
    width: 312px;
    height: 100%;
  }

  ._expanded {
    width: 44px;
    height: 44px;
    overflow: hidden;
  }

  #logo {
    position: fixed;
    margin-right: 8px;
    width: 20px;
    height: 20px;
    background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 20 20" fill="none"><path d="M14.375 10.007C13.4334 10.0079 12.5171 10.3126 11.7625 10.8758L9.12499 8.23829C9.69483 7.48913 10.0023 6.57328 9.99999 5.63204C10.0025 4.64635 9.67199 3.68872 9.06216 2.91433C8.45232 2.13994 7.59885 1.59417 6.64006 1.36548C5.68127 1.13679 4.67334 1.23857 3.77963 1.65433C2.88592 2.07009 2.15879 2.77547 1.71609 3.65615C1.27339 4.53683 1.14105 5.5412 1.34053 6.50649C1.54001 7.47178 2.05962 8.34143 2.81514 8.97449C3.57066 9.60756 4.51782 9.96694 5.50312 9.9944C6.48843 10.0219 7.45413 9.71579 8.24374 9.12579L10.875 11.7633C10.2851 12.5527 9.97907 13.5181 10.0063 14.5031C10.0336 15.4882 10.3926 16.4352 11.0253 17.1907C11.6579 17.9462 12.527 18.4661 13.492 18.666C14.4569 18.866 15.4611 18.7343 16.3418 18.2924C17.2226 17.8504 17.9283 17.1241 18.3448 16.231C18.7612 15.3379 18.864 14.3303 18.6364 13.3715C18.4088 12.4128 17.8642 11.5589 17.0907 10.9483C16.3173 10.3376 15.3604 10.006 14.375 10.007V10.007ZM2.49999 5.63204C2.49999 5.01397 2.68327 4.40978 3.02665 3.89588C3.37003 3.38198 3.85809 2.98144 4.42911 2.74491C5.00012 2.50839 5.62846 2.4465 6.23465 2.56708C6.84084 2.68766 7.39766 2.98529 7.8347 3.42233C8.27174 3.85937 8.56937 4.41619 8.68995 5.02238C8.81052 5.62857 8.74864 6.2569 8.51212 6.82792C8.27559 7.39894 7.87505 7.887 7.36115 8.23038C6.84724 8.57376 6.24306 8.75704 5.62499 8.75704C4.79619 8.75704 4.00133 8.4278 3.41528 7.84175C2.82923 7.25569 2.49999 6.46084 2.49999 5.63204V5.63204Z" fill="%233B3CD0"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
    cursor: pointer;
  }

  .title {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
  }

  #plugin-title {
    color: var(--brand-blue-main);
    text-align: center;
    margin: 0 0 0 32px;
    font-family: 'Roboto';
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 22px;
    text-wrap: nowrap;
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  #close {
    width: 20px;
    height: 20px;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M15.625 4.375L4.375 15.625" stroke="%23595959" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.625 15.625L4.375 4.375" stroke="%23595959" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
    cursor: pointer;
  }

  #layer-title {
    color: var(--color-secondary-main);
    font-family: 'Noto Sans';
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 22px;
    /* 157.143% */
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  .layer-list {
    display: flex;
    flex-direction: column;
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  .layer-list__item {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    color: var(--color-secondary-weak);
    text-align: center;
    /* EN/Body/regular */
    font-family: 'Noto Sans';
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .layer-list__item:last-of-type {
    margin-bottom: 0;
  }

  .layer-list__item:hover {
    background: var(--color-content-with-background);
  }

  .item-title__wrap {
    display: flex;
    flex-direction: row;
    width: 100%;
    align-items: center;
    text-align: center;
    padding: 8px;
    background: inherit;
    border: none;
    cursor: pointer;
  }

  .item-marker {
    width: 20px;
    height: 20px;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.93766 16.1042C10.7091 15.49 11.4803 14.7959 12.202 14.034C14.307 11.8122 15.5837 9.47155 15.5837 7.08333C15.5837 3.17132 12.4123 0 8.50033 0C4.58831 0 1.41699 3.17132 1.41699 7.08333C1.41699 9.47155 2.69369 11.8122 4.79861 14.034C5.52037 14.7959 6.29156 15.49 7.06299 16.1042C7.33342 16.3196 7.58504 16.5099 7.81168 16.6736C7.94979 16.7733 8.05043 16.843 8.10741 16.881C8.34534 17.0397 8.65531 17.0397 8.89324 16.881C8.95022 16.843 9.05086 16.7733 9.18897 16.6736C9.41561 16.5099 9.66723 16.3196 9.93766 16.1042ZM11.1736 13.0597C10.5008 13.7699 9.77789 14.4205 9.05518 14.996C8.85791 15.1531 8.67196 15.2955 8.50033 15.4223C8.32869 15.2955 8.14274 15.1531 7.94547 14.996C7.22276 14.4205 6.49982 13.7699 5.82704 13.0597C3.94758 11.0758 2.83366 9.03365 2.83366 7.08333C2.83366 3.95372 5.37071 1.41667 8.50033 1.41667C11.6299 1.41667 14.167 3.95372 14.167 7.08333C14.167 9.03365 13.0531 11.0758 11.1736 13.0597ZM8.50033 9.91667C6.93552 9.91667 5.66699 8.64814 5.66699 7.08333C5.66699 5.51853 6.93552 4.25 8.50033 4.25C10.0651 4.25 11.3337 5.51853 11.3337 7.08333C11.3337 8.64814 10.0651 9.91667 8.50033 9.91667ZM9.91699 7.08333C9.91699 7.86574 9.28273 8.5 8.50033 8.5C7.71792 8.5 7.08366 7.86574 7.08366 7.08333C7.08366 6.30093 7.71792 5.66667 8.50033 5.66667C9.28273 5.66667 9.91699 6.30093 9.91699 7.08333Z" fill="%23141414"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }

  .item-eye {
    width: 20px;
    height: 20px;
    border: none;
    padding: 16px 16px;
    -webkit-transition-duration: 0.2s;
    -o-transition-duration: 0.2s;
    transition-duration: 0.2s;
    cursor: pointer;
  }

  ._show {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.633488 7.23029C0.361227 7.65186 0.17435 7.98409 0.0747807 8.18322C-0.0249269 8.38264 -0.0249269 8.61736 0.0747807 8.81678C0.17435 9.01591 0.361227 9.34814 0.633488 9.76971C1.0841 10.4674 1.6158 11.1647 2.22804 11.8178C4.01009 13.7187 6.10597 14.875 8.5 14.875C10.894 14.875 12.9899 13.7187 14.772 11.8178C15.3842 11.1647 15.9159 10.4674 16.3665 9.76971C16.6388 9.34814 16.8256 9.01591 16.9252 8.81678C17.0249 8.61736 17.0249 8.38264 16.9252 8.18322C16.8256 7.98409 16.6388 7.65186 16.3665 7.23029C15.9159 6.53257 15.3842 5.83526 14.772 5.18221C12.9899 3.28135 10.894 2.125 8.5 2.125C6.10597 2.125 4.01009 3.28135 2.22804 5.18221C1.6158 5.83526 1.0841 6.53257 0.633488 7.23029ZM3.26159 10.8489C2.71171 10.2623 2.23071 9.63152 1.82358 9.00113C1.70803 8.8222 1.60554 8.65415 1.51638 8.5C1.60554 8.34584 1.70803 8.1778 1.82358 7.99887C2.23071 7.36848 2.71171 6.73765 3.26159 6.15112C4.79984 4.51032 6.55552 3.54167 8.50004 3.54167C10.4446 3.54167 12.2002 4.51032 13.7385 6.15112C14.2884 6.73765 14.7694 7.36848 15.1765 7.99887C15.2921 8.1778 15.3945 8.34584 15.4837 8.5C15.3945 8.65415 15.2921 8.8222 15.1765 9.00113C14.7694 9.63152 14.2884 10.2623 13.7385 10.8489C12.2002 12.4897 10.4446 13.4583 8.50004 13.4583C6.55552 13.4583 4.79984 12.4897 3.26159 10.8489ZM8.5 11.3333C6.93519 11.3333 5.66667 10.0648 5.66667 8.5C5.66667 6.93519 6.93519 5.66667 8.5 5.66667C10.0648 5.66667 11.3333 6.93519 11.3333 8.5C11.3333 10.0648 10.0648 11.3333 8.5 11.3333ZM9.91667 8.5C9.91667 9.2824 9.2824 9.91667 8.5 9.91667C7.7176 9.91667 7.08333 9.2824 7.08333 8.5C7.08333 7.7176 7.7176 7.08333 8.5 7.08333C9.2824 7.08333 9.91667 7.7176 9.91667 8.5Z" fill="%23141414"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }

  ._hide {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.04565 3.98846L0.195262 1.13807C-0.0650873 0.877722 -0.0650873 0.455612 0.195262 0.195262C0.455612 -0.0650874 0.877722 -0.0650874 1.13807 0.195262L4.50362 3.56081C4.50847 3.56552 4.51327 3.57032 4.51801 3.5752L7.05546 6.11265C7.05701 6.11418 7.05855 6.11573 7.06009 6.11728L9.88281 8.94C9.8843 8.94148 9.88579 8.94297 9.88727 8.94446L12.4236 11.4808C12.4285 11.4855 12.4333 11.4903 12.438 11.4952L15.8047 14.8619C16.0651 15.1223 16.0651 15.5444 15.8047 15.8047C15.5444 16.0651 15.1223 16.0651 14.8619 15.8047L11.884 12.8269C10.7307 13.569 9.3885 13.9774 8 14C5.7468 14 3.77421 12.9117 2.09698 11.1226C1.52075 10.508 1.02033 9.8517 0.596224 9.19502C0.339978 8.79825 0.164094 8.48557 0.0703819 8.29814C-0.0264925 8.10439 -0.023193 7.87566 0.0792296 7.68478C0.83357 6.279 1.8398 5.02644 3.04565 3.98846ZM3.9914 4.93421C2.96687 5.80092 2.09956 6.83879 1.42837 8.00213C1.512 8.14663 1.60805 8.30407 1.71628 8.47165C2.09946 9.06496 2.55217 9.65868 3.06969 10.2107C4.51746 11.755 6.16987 12.6667 7.9891 12.6668C9.02133 12.6499 10.0276 12.3692 10.9143 11.8571L9.36655 10.3094C8.75636 10.6918 8.00709 10.8167 7.29027 10.6336C6.34544 10.3923 5.60766 9.65456 5.36637 8.70973C5.18331 7.99291 5.30817 7.24364 5.69064 6.63345L3.9914 4.93421ZM6.68526 7.62807C6.60569 7.86671 6.59375 8.12728 6.65824 8.37981C6.77889 8.85223 7.14778 9.22111 7.62019 9.34176C7.87272 9.40625 8.1333 9.39431 8.37193 9.31474L6.68526 7.62807ZM13.4641 10.6368C13.1824 10.3997 13.1462 9.97916 13.3832 9.69744C13.8293 9.16735 14.2271 8.59877 14.572 7.9985C14.4883 7.85382 14.3921 7.69617 14.2837 7.52835C13.9005 6.93504 13.4478 6.34132 12.9303 5.78929C11.4825 4.24501 9.83013 3.33333 7.99843 3.33333C7.57882 3.33235 7.16051 3.38015 6.75194 3.47579C6.39344 3.5597 6.03479 3.33711 5.95088 2.97861C5.86696 2.62011 6.08956 2.26146 6.44806 2.17755C6.95726 2.05835 7.4786 1.99877 8 2C10.2532 2 12.2258 3.08833 13.903 4.87737C14.4792 5.49201 14.9797 6.1483 15.4038 6.80498C15.66 7.20175 15.8359 7.51443 15.9296 7.70186C16.0263 7.89527 16.0232 8.12357 15.9213 8.31428C15.4947 9.11227 14.986 9.86355 14.4034 10.5559C14.1664 10.8376 13.7458 10.8738 13.4641 10.6368Z" fill="%23C7C5C5"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }
</style>
<div id="wrapper" class="_open">
  <div class="title">
    <div id="logo">
    </div>
    <p id="plugin-title">ArcGIS connector</p>
    <div id="close"></div>
  </div>
  <p id="layer-title">Layer list</p>
  <input type="hidden" id="data-store" />
  <div id="layer-list" class="layer-list">

  </div>

  <script src="https://unpkg.com/togeojson@0.16.0/togeojson.js"></script>
  <script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
  <script>

    let reearth;
    let property;
    let layers;
    let newProperty;
    let itemEyeID = "itemEye_ID__";

    let startTime = new Date();

    // expireIn indicate token validity period. 60 is for debugging. It should be 7000 in actual operation.
    const expireIn = 60;

    let dataStore = [];
    dataStore.push({
      itemId: "",
      layerId: "",
      arr: [],
      centerPoint: [],
      cameraHeight: [],
    });

    let iconCoords = Array();


    let API_URL
    let ARCGIS_URL
    let client_id
    let client_secret


    let TokenURL = 'https://www.arcgis.com/sharing/rest/oauth2/token'
    let token_url
    let token = "";
    let param = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-Esri-Authorization': ""
    };

    let wrapper = document.getElementById('wrapper');
    let layersTitle = document.getElementById('layer-title')
    let layerList = document.getElementById("layer-list");
    let pluginTitle = document.getElementById("plugin-title");

    document.getElementById('close').addEventListener('click', hideWrapper);
    function hideWrapper() {
      wrapper.classList.remove("_open");
      wrapper.classList.add("_expanded");
      layersTitle.style.opacity = "0";
      pluginTitle.style.opacity = "0";
    }

    document.getElementById('logo').addEventListener('click', handleWrapper);
    function handleWrapper() {
      wrapper.classList.add("_open");
      wrapper.classList.remove("_expanded");
      layersTitle.style.opacity = "1";
      pluginTitle.style.opacity = "1";
    }


    // Get different between two json object
    function getObjectDiff(obj1, obj2) {
      let diff = {};
      if (obj1 && obj2) {
        // Check for keys in obj1 that are not in obj2
        for (let key in obj1) {
          if (!obj2.hasOwnProperty(key)) {
            diff[key] = [obj1[key], undefined];
          }
        }
        // Check for keys in obj2 that are not in obj1
        for (let key in obj2) {
          if (!obj1.hasOwnProperty(key)) {
            diff[key] = [undefined, obj2[key]];
          }
        }
        // Check for keys in both objects
        for (let key in obj1) {
          if (obj2.hasOwnProperty(key)) {
            if (typeof obj1[key] === 'object') {
              diff[key] = getObjectDiff(obj1[key], obj2[key]);
            } else if (obj1[key] !== obj2[key]) {
              diff[key] = [obj1[key], obj2[key]];
            }
          }
        }
      }

      return diff;
    }
    let oldProperties

    function setProperties(pro) {
      API_URL = pro.client_data.URL;
      ARCGIS_URL = pro.client_data.arcgis_URL;
      client_id = pro.client_data.client_ID;
      client_secret = pro.client_data.client_secret;

      token_url = TokenURL + "?client_id=" + client_id + "&grant_type=client_credentials&client_secret=" + client_secret;

      hideLayers(pro.data_list);

    }
    //  ./setProperties

    window.addEventListener("message", async function (e) {
      if (e.source !== parent) return;
      reearth = e.source.reearth;
      layers = reearth.layers.layers;


      let diff = getObjectDiff(property, e.data.property)
      // console.log("diff: ", diff)
      if (JSON.stringify(diff) === "{}") {
        // console.log("first time call getToken()")
        setProperties(e.data.property)

        get_token().then(() => {
          handleData(e.data.property);
        });
      } else if (diff.hasOwnProperty("client_data") && (
        diff.client_data.hasOwnProperty("client_ID") ||
        diff.client_data.hasOwnProperty("client_secret") ||
        diff.client_data.hasOwnProperty("URL") ||
        diff.client_data.hasOwnProperty("arcgis_URL"))) {
        // console.log("get new token and handle get token() when change client_data")
        setProperties(e.data.property)
        get_token().then(() => {
          handleData(e.data.property);
        });
      }
      else {
        // console.log("Just handle data_list()");
        hideLayers(e.data.property.data_list)
        handleData(e.data.property);
      }

      property = e.data.property;
    });
    //  ./ window.addEventListener


    async function get_token() {
      return new Promise((resolve, reject) => {
        fetch(token_url)
          .then(function (response) {
            if (response.ok) {
              return response.json();
            } else {
              throw new Error("Could not reach the API: " + response.statusText);
            }
          })
          .then(function (data) {
            token = "Bearer " + data['access_token'];
            param['X-Esri-Authorization'] = token;
            // console.log(token);
            resolve(); // Resolve the Promise when token retrieval is successful
          })
          .catch(function (error) {
            console.error(error);
            reject(error); // Reject the Promise if there's an error
          });
      });
    }

    // hide layers if item deleted from Data List
    function hideLayers(list) {
      if (!list || 0 === list.length) {
        let filteredLayers = layers.filter(layer => layer.id)
        filteredLayers.forEach(layer => {
          reearth.layers.hide(layer.id)
          let layerId = layer.id;

        })
      } else {
        const list_id = list.map(obj => obj.id);
        let filteredLayers = layers.filter(layer => !list_id.includes(layer.id));
        filteredLayers.forEach(layer => {
          reearth.layers.hide(layer.id)
          let layerId = layer.id;
        });
      }
    }

    function download(itemID, dataItem) {
      let itemElm = document.getElementById(itemID)
      let dataType = itemElm.getAttribute("data-type")

      let currentTime = new Date();
      let timeDiff = (currentTime.getTime() - startTime.getTime()) / 1000;
      if (timeDiff > expireIn) {
        console.log("token is expiered!");
        get_token();
        // console.log("get new token");
        startTime = new Date();
      }
      fetch(API_URL, {
        method: 'POST',
        headers: param,
        body: JSON.stringify({ "id": itemID, "arcgis_url": ARCGIS_URL })
      }).then(function (response) {
        if (response.ok) {
          if (dataType == "kml") {
            return response.text();
          } else {
            return response.json();
          }
        } else {
          throw new Error("Could not reach the API" + response.statusText);
        }
      }).then(function (data) {
        if (!data.hasOwnProperty("errorMessage")) {
          if (dataType == "kml") {
            let result = handleKMLFile(data)
            // console.log("kml result", result);
            showGeojson(result.data, result.centerPoint, result.height, itemID, dataType, dataItem)
          } else {
            let geojsonData = data;
            // console.log("geojsonData", geojsonData);
            let center = turf.center(geojsonData);
            let height = 50000
            showGeojson(geojsonData, center, height, itemID, dataType, dataItem)
          }
        } else {
          //Show error
          if (data.errorType == "Function.ResponseSizeTooLarge") {
            alert("File size is too large")
          } else {
            // console.log(data)
          }
        }
      }).catch(function (error) {
        console.log(error)
        //Hide the layer if exist
        let found = dataStore.some(obj => obj.itemId == itemID)
        if (found) {
          reearth.layers.hide(itemID)
        }
      });
    }

    // handle data from ArcGis create ui blocks
    function handleData(files) {
      // remove remove sample of ui for layer-list and create new one with items 
      document.getElementById("layer-list").remove();
      let layerList = document.createElement('div');
      layerList.classList.add("layer-list");
      layerList.id = "layer-list";
      document.getElementById('wrapper').appendChild(layerList);

      let dataList = files.data_list;

      i = 0;
      // create items for layer list
      dataList.forEach(dataItem => {

        if (dataItem.layer_name && dataItem.symbol_ID) {
          i++

          let layerName = dataItem.layer_name;
          let itemID = dataItem.symbol_ID;

          let layerList__item = document.createElement('div');
          layerList__item.classList.add('layer-list__item');

          let itemTitle__wrap = document.createElement('button');
          itemTitle__wrap.classList.add('item-title__wrap');
          itemTitle__wrap.id = itemID;
          itemTitle__wrap.setAttribute("data-type", dataItem.data_type);
          let dataType = itemTitle__wrap.getAttribute("data-type")

          let itemMarker = document.createElement('div');
          itemMarker.classList.add('item-marker');

          let itemTitle = document.createElement('div');
          itemTitle.classList.add('item-title');
          itemTitle.id = "itemTitle__" + i;
          itemTitle.textContent = layerName;

          let itemEye = document.createElement('button');
          itemEye.classList.add('item-eye');
          itemEyeID = itemEyeID + i;
          itemEye.id = itemEyeID;
          itemEye.classList.add('_show');

          layerList.appendChild(layerList__item);
          layerList__item.appendChild(itemTitle__wrap);
          itemTitle__wrap.appendChild(itemMarker);
          itemTitle__wrap.appendChild(itemTitle);
          layerList__item.appendChild(itemEye);

          //  push to dataStore item id for each item from layer list, as layer list created every time new, needs some date to store them 
          let found = dataStore.some(obj => obj.itemId == itemID)
          if (!found) {
            dataStore.push({ itemId: itemID, layerId: "", arr: [], centerPoint: [], cameraHeight: [], })
            download(itemID, dataItem);
          } else {
            // if item created push to dataStore layer Id
            let findItemId = dataStore.find(obj => obj.itemId === itemID)
            let layerId = findItemId.layerId;
            layerList__item.id = layerId;

            // hide and show layers turn on/off visible button in widget
            if (dataItem.visible === true || dataItem.visible === undefined) {
              itemEye.classList.remove('_hide');
              itemEye.classList.add('_show');
              reearth.layers.show(layerId);
            } else {
              itemEye.classList.remove('_show');
              itemEye.classList.add('_hide');
              reearth.layers.hide(layerId);
            }

            if (layerId && dataItem.data_type !== "default" && dataItem.data_type !== "kml") {
              // getting layer Id and data type to override properties, if file already downloaded
              let geoJsonData = reearth.layers.findById(layerId).property.default.url;

              if (geoJsonData.type == "FeatureCollection") {
                overrideProperties(geoJsonData, dataItem, layerId);
              }

              reearth.layers.overrideProperty(layerId, {
                default: {
                  clampToGround: dataItem.clampToGround,
                },
              })

            }
          }

          document.getElementById('data-store').setAttribute('data-store', JSON.stringify(dataStore));

          // move camera if click ui button
          itemTitle__wrap.addEventListener("click", moveCamera);
          function moveCamera() {
            let layerId = itemTitle__wrap.parentElement.id
            let file = reearth.layers.findById(layerId).property.default.url;

            let findItemId = dataStore.find(obj => obj.itemId == itemID);
            let center = findItemId.centerPoint;
            let cameraHeight = findItemId.cameraHeight;

            // console.log("center", center);
            // console.log("cameraHeight", cameraHeight);

            reearth.camera.flyTo({
              lat: center[1],
              lng: center[0],
              height: cameraHeight || 50000,
            }, {
              duration: 2
            });
          }
        }
      });
      //   ./forEach

      // hide and show layers by clicking one eye button (ui)
      eye_btns = document.querySelectorAll('.item-eye');

      let handleLayer = e => {
        let layer_id = e.target.parentElement.id;
        reearth.layers.layers;

        var btnClass = e.target.classList;

        if (btnClass.contains('_show')) {
          reearth.layers.hide(layer_id);

          let findlayerId = dataStore.find(obj => obj.layerId === layer_id);
          if (findlayerId.arr.length > 0) {
            findlayerId.arr.forEach((element) => {
              let markerId = element;
              reearth.layers.hide(markerId);
            });
          }
          btnClass.remove('_show');
          btnClass.add('_hide');

        } else {
          reearth.layers.show(layer_id);

          let findlayerId = dataStore.find(obj => obj.layerId === layer_id);
          if (findlayerId.arr.length > 0) {
            findlayerId.arr.forEach((element) => {
              let markerId = element;
              reearth.layers.show(markerId);
            });
          }
          btnClass.remove('_hide');
          btnClass.add('_show');

        }
      }

      for (let eye_btn of eye_btns) {
        eye_btn.addEventListener("click", handleLayer);
      }
      //  ./hide and show layers by clicking one eye button (ui)

    };
    //  ./handleData

    let geojsonLayerId
    function showGeojson(data, center, height, itemID, dataType, dataItem) {

      let findItemId = dataStore.find(obj => obj.itemId == itemID);
      let centerPoint = center.geometry.coordinates
      findItemId.centerPoint = centerPoint;

      let cameraHeight = height;
      // console.log(cameraHeight);
      let geoJson = turf.featureCollection([]);
      let url;


      if ((data.type == "FeatureCollection")) {

        let multiPolygon = turf.featureCollection([]);
        let poly = turf.featureCollection([]);
        let lines = turf.featureCollection([]);
        let points = turf.featureCollection([]);
        let multiPoints = turf.featureCollection([]);

        let polygonProp = ({ "stroke": "#000000", "stroke-width": "1" });

        // MultiPolygon and Polygon are rewriting to prevent a bug with a data visualization
        for (let i = 0; i < data.features.length; i++) {
          if (data.features[i].geometry.type == "MultiPolygon") {
            multiPolygon.features.push(data.features[i])
          } else if (data.features[i].geometry.type == "Polygon") {
            poly.features.push(data.features[i])
          }
        }

        turf.featureEach(multiPolygon, function (currentFeature) {
          let multipoligonCoords = turf.getCoords(currentFeature);
          multipoligonCoords.forEach((e) => {
            let line = turf.multiLineString(turf.getCoords(e));
            line.properties = polygonProp;
            data.features.push(line);
          })
        });

        turf.featureEach(poly, function (currentFeature) {
          currentFeature.properties["stroke-width"] = 0;
          let linestring = turf.lineString(turf.getCoords(currentFeature)[0])
          linestring.properties["stroke"] = "#000000";
          data.features.push(linestring);
        })

        // for publishing project with correct data type dividing and rewrited properties
        for (let i = 0; i < data.features.length; i++) {
          if ((data.features[i].geometry.type == "LineString") || (data.features[i].geometry.type == "MultiLineString")) {
            lines.features.push(data.features[i]);
          } else if (data.features[i].geometry.type === "Point") {
            points.features.push(data.features[i]);
          } else if (data.features[i].geometry.type === "MultiPoint") {
            multiPoints.features.push(data.features[i]);
          }
        }

        // transform lines and points to Polygons and counting area of every Polygons
        let area = (turf.area(multiPolygon)) + (turf.area(poly) * 2) || 0;
        let linesLength = turf.area(turf.bboxPolygon(turf.bbox(lines))) || 0;
        let pointsArea = turf.area(turf.envelope(points)) || 0;
        let multipointsArea = turf.area(turf.envelope(multiPoints)) || 0;
        let pointsLength = pointsArea + multipointsArea;

        // count math square to get diagonal with formula d = √2a this will be the height for camera
        cameraHeight = Math.round(Math.sqrt(2 * (area + linesLength + pointsLength)));

        findItemId.cameraHeight = cameraHeight;

        // console.log("area: ", area);
        // console.log("linesLength: ", linesLength);
        // console.log("pointsLength: ", pointsLength);
        // console.log("cameraHeight: ", cameraHeight);


        switch (dataType) {

          case "point":
            let options = { steps: 20, units: 'meters' };
            var circle;
            var border;

            let strokeProp = ({ "stroke": dataItem.point_outline_color || "#000000", "stroke-width": dataItem.point_outline_width || "2" });
            let radius = dataItem.point_size || "1500";
            let pointFill = dataItem.point_color || "yellow";

            turf.featureEach(multiPoints, function (currentFeature, featureIndex) {
              let multipoints = turf.getCoords(currentFeature);
              multipoints.forEach((el) => {
                let center = turf.getCoords(el);
                circle = turf.circle(center, radius, options);
                circle.properties["fill"] = pointFill;

                border = turf.polygonToLine(circle);
                border.properties = strokeProp;
                geoJson.features.push(circle);
                geoJson.features.push(border);
              })
            });

            turf.featureEach(points, function (currentFeature, featureIndex) {
              let center = turf.getCoord(currentFeature);
              circle = turf.circle(center, radius, options);
              circle.properties["fill"] = pointFill;

              border = turf.polygonToLine(circle);
              border.properties = strokeProp;
              geoJson.features.push(circle);
              geoJson.features.push(border);
            });

            // 
            dataType = "geojson"
            url = geoJson
            break;

          case "icon":
            dataType = "geojson"

            let iconCoords = Array();
            let imageUrl = dataItem.image_URL
            let imageSize = dataItem.image_size || "1";

            multiPoints.features.map((element) => {
              let multipoints = turf.getCoords(element);
              multipoints.forEach((el) => {
                let coord = turf.getCoord(el);
                iconCoords.push(coord);
                let geometry = ({ "name": "markers", "coordinates": coord });
                geoJson.features.push(turf.feature(geometry));
              })
            })

            points.features.map((element) => {
              let coord = element.geometry.coordinates
              iconCoords.push(coord);
              let geometry = ({ "name": "markers", "coordinates": coord });
              geoJson.features.push(turf.feature(geometry));
            })

            iconCoords.forEach((element) => {

              let long = element[0];
              let lat = element[1];

              let markerId = reearth.layers.add({
                extensionId: "marker",
                isVisible: true,
                title: "marker",
                property: {
                  default: {
                    image: imageUrl,
                    imageSize: imageSize,
                    heightReference: "clamp",
                    location: {
                      lat: lat,
                      lng: long,
                    },
                  }
                }
              });

              let findItemId = dataStore.find(obj => obj.itemId == itemID)
              if (findItemId) {
                findItemId.arr.push(markerId);
              }
            })

            url = geoJson
            break;

          case "line":

            let lineProp = ({ "stroke": dataItem.line_color, "stroke-width": dataItem.line_width || "1" });

            lines.features.forEach((line) => {
              line.properties = lineProp;
              geoJson.features.push(line);
            })
            url = geoJson
            dataType = "geojson"
            break;

          case "polygon":
            // getting properties data from widget (dataItem... ) and implement them to the features properties
            let polygonProp = ({ "stroke": dataItem.outline_color, "stroke-width": "1", });

            turf.featureEach(multiPolygon, function (currentFeature) {
              currentFeature.properties["fill"] = dataItem.polygon_color;
              geoJson.features.push(currentFeature);
              let multipoligonCoords = turf.getCoords(currentFeature);
              multipoligonCoords.forEach((e) => {
                let line = turf.multiLineString(turf.getCoords(e));
                line.properties = polygonProp;
                geoJson.features.push(line);
              })
            });

            turf.featureEach(poly, function (currentFeature) {
              currentFeature.properties["fill"] = dataItem.polygon_color;
              currentFeature.properties["stroke-width"] = 0;
              geoJson.features.push(currentFeature);
              let linestring = turf.lineString(turf.getCoords(currentFeature)[0])
              linestring.properties["stroke"] = dataItem.outline_color;
              geoJson.features.push(linestring);
            })

            url = geoJson;
            dataType = "geojson"
            break;

          default:
            dataType = "geojson"
            url = data
            break;
        }
      } else {
        dataType = "kml"
        url = data;
      }

      findItemId.cameraHeight = cameraHeight;
      // upload geojson or kml file
      geojsonLayerId = reearth.layers.add({
        extensionId: "resource",
        isVisible: true,
        title: dataType,
        property: {
          default: {
            url: url,
            type: dataType,
            clampToGround: dataItem.clampToGround,
          },
        },
      })

      reearth.camera.flyTo({
        lat: center.geometry.coordinates[1],
        lng: center.geometry.coordinates[0],
        height: cameraHeight || 50000,
      }, {
        duration: 2
      });

      // push layer id to dataStore
      findItemId.layerId = geojsonLayerId;

      document.getElementById(itemID).parentElement.setAttribute('id', geojsonLayerId)
    };
    //  ./showGeojson


    // override properties from default point marker or icon to circle
    function overridePoinProperties(points, layerId, strokeProp, radius, pointFill) {

      let geoJson = turf.featureCollection([]);
      var center;
      var options = { steps: 20, units: 'meters' };
      var circle;
      var line;
      let multipoints;

      points.features.map((element) => {
        if (element.geometry.type == "MultiPoint") {
          turf.featureEach(points, function (currentFeature, featureIndex) {

            multipoints = turf.getCoords(currentFeature);
            multipoints.forEach((el) => {
              center = turf.getCoords(el);
              circle = turf.circle(center, radius, options);
              circle.properties["fill"] = pointFill;

              line = turf.polygonToLine(circle);
              line.properties = strokeProp;

              geoJson.features.push(circle);
              geoJson.features.push(line);
            })
          });

        } else if (element.geometry.type == "Point") {

          turf.featureEach(points, function (currentFeature, featureIndex) {

            center = turf.getCoord(currentFeature);
            circle = turf.circle(center, radius, options);
            circle.properties["fill"] = pointFill;

            line = turf.polygonToLine(circle);
            line.properties = strokeProp;
            geoJson.features.push(circle);
            geoJson.features.push(line);
          });

        } else if (element.geometry.name === "markers") {
          let coords = element.geometry.coordinates;
          circle = turf.circle(coords, radius, options);
          circle.properties["fill"] = pointFill;

          line = turf.polygonToLine(circle);
          line.properties = strokeProp;
          geoJson.features.push(circle);
          geoJson.features.push(line);
        }
      });

      parent.postMessage({ type: "Properties", layerId, geoJson }, "*");
    }
    //  ./overridePoinProperties

    // override properties from default point marker or circle to icon
    function overrideIconProperties(iconCoords, layerId, imageUrl, imageSize) {

      let findlayerId = dataStore.find(obj => obj.layerId === layerId)
      if (findlayerId.arr.length == 0) {

        iconCoords.forEach((element) => {

          let long = element[0];
          let lat = element[1];

          let markerId = reearth.layers.add({
            extensionId: "marker",
            isVisible: true,
            title: "marker",
            property: {
              default: {
                image: imageUrl,
                imageSize: imageSize,
                heightReference: "clamp",
                location: {
                  lat: lat,
                  lng: long,
                },
              }
            }
          });
          reearth.layers.show(markerId);
          let findlayerId = dataStore.find(obj => obj.layerId === layerId)
          if (findlayerId) {
            findlayerId.arr.push(markerId);
          }
        })
      } else {
        findlayerId.arr.forEach((element) => {
          let markerId = element;
          reearth.layers.show(markerId);
          reearth.layers.overrideProperty((markerId), {
            default: {
              image: imageUrl,
              imageSize: imageSize,
            }
          });
        });
      }

    }
    //  ./overrideIconProperties


    function overrideLineProperties(lines, layerId, lineProp) {

      let geoJson = turf.featureCollection([]);

      lines.features.forEach((line) => {
        line.properties = lineProp;
        geoJson.features.push(line);
      })
      parent.postMessage({ type: "Properties", layerId, geoJson }, "*");
    }
    //  ./overrideLineProperties

    function overridePolygonProperties(polygons, layerId, polygonFill, polygonProp) {

      let lineString
      let geoJson = turf.featureCollection([]);
      let multi = turf.featureCollection([]);
      let poly = turf.featureCollection([]);

      for (let i = 0; i < polygons.features.length; i++) {
        if (polygons.features[i].geometry.type == "MultiPolygon") {
          multi.features.push(polygons.features[i])
        } else {
          poly.features.push(polygons.features[i])
        }
      }

      turf.featureEach(multi, function (currentFeature) {
        currentFeature.properties["fill"] = polygonFill;
        let multipoligonCoords = turf.getCoords(currentFeature);
        multipoligonCoords.forEach((e) => {
          let line = turf.multiLineString(turf.getCoords(e));
          line.properties = polygonProp;
          geoJson.features.push(currentFeature);
          geoJson.features.push(line);
        })
      });

      turf.featureEach(poly, function (currentFeature, featureIndex) {
        currentFeature.properties["fill"] = polygonFill;
        currentFeature.properties["stroke-width"] = 0;
        linestring = turf.lineString(turf.getCoords(currentFeature)[0])
        linestring.properties["stroke"] = polygonProp.stroke
        geoJson.features.push(currentFeature);
        geoJson.features.push(linestring);

      })

      parent.postMessage({ type: "Properties", layerId, geoJson }, "*");
    }
    //  ./overridePolygonProperties


    // getting properties from widget and override them
    function overrideProperties(geoJsonData, dataItem, layerId) {

      let dataType = dataItem.data_type
      let isInvalid = false;

      let lines = turf.featureCollection([]);
      let points = turf.featureCollection([]);
      let polygons = turf.featureCollection([]);

      // sort features by type
      for (let i = 0; i < geoJsonData.features.length; i++) {
        if ((geoJsonData.features[i].geometry.type === "Point") || (geoJsonData.features[i].geometry.type === "MultiPoint") || (geoJsonData.features[i].geometry.name === "markers")) {
          points.features.push(geoJsonData.features[i]);
        } else if ((geoJsonData.features[i].geometry.type === "LineString") || (geoJsonData.features[i].geometry.type === "MultiLineString")) {
          lines.features.push(geoJsonData.features[i]);
        } else if ((geoJsonData.features[i].geometry.type === "Polygon") || (geoJsonData.features[i].geometry.type === "MultiPolygon")) {
          polygons.features.push(geoJsonData.features[i]);
        }
      }

      switch (dataType) {
        case 'point':
          isInvalid = false;
          if (points.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {

            let findlayerId = dataStore.find(obj => obj.layerId === layerId);
            if (findlayerId && findlayerId.arr.length > 0) {
              findlayerId.arr.forEach((element) => {
                let markerId = element;
                reearth.layers.overrideProperty((markerId), {
                  default: {
                    image: [],
                    imageSize: 0,
                  }
                });

              });
            }


            let strokeProp = ({ "stroke": dataItem.point_outline_color || "#000000", "stroke-width": dataItem.point_outline_width || "3" });
            let radius = dataItem.point_size || "1500";
            let pointFill = dataItem.point_color || "yellow";

            overridePoinProperties(points, layerId, strokeProp, radius, pointFill);
          } else {
            alert("Please, choose correct Data Type")
          }

          break

        case 'icon':

          iconCoords = Array()
          isInvalid = false;
          let coord;

          if (points.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {

            let imageUrl = dataItem.image_URL
            let imageSize = dataItem.image_size || "1";

            points.features.map((element) => {
              if (element.geometry.type == "MultiPoint") {
                multipoints = turf.getCoords(element);
                multipoints.forEach((el) => {
                  coord = turf.getCoord(el);
                  iconCoords.push(coord);
                })
              } else if ((element.geometry.type == "Point") || (element.geometry.name === "markers")) {
                coord = element.geometry.coordinates
                iconCoords.push(coord);
              }
            })

            overrideIconProperties(iconCoords, layerId, imageUrl, imageSize);

            let geoJson = turf.featureCollection([]);
            parent.postMessage({ type: "Properties", layerId, geoJson }, "*");

          } else {
            alert("Please, choose correct Data Type")
          }
          break

        case 'line':
          isInvalid = false;

          if (lines.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {
            let findlayerId = dataStore.find(obj => obj.layerId === layerId);
            if (findlayerId && findlayerId.arr.length > 0) {
              findlayerId.arr.forEach((element) => {
                let markerId = element;
                reearth.layers.overrideProperty((markerId), {
                  default: {
                    image: [],
                    imageSize: 0,
                  }
                });
              });
            }

            let lineProp = ({ "stroke": dataItem.line_color || "yellow", "stroke-width": dataItem.line_width || "1" });

            overrideLineProperties(lines, layerId, lineProp);
          } else {
            alert("Please, choose correct Data Type")
          }
          break

        case 'polygon':

          isInvalid = false;

          if (polygons.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {
            let findlayerId = dataStore.find(obj => obj.layerId === layerId);
            if (findlayerId && findlayerId.arr.length > 0) {
              findlayerId.arr.forEach((element) => {
                let markerId = element;
                // reearth.layers.hide(markerId);
                reearth.layers.overrideProperty((markerId), {
                  default: {
                    image: [],
                    imageSize: 0,
                  }
                });
              });
            }
            let polygonFill = dataItem.polygon_color || "yellow";
            let polygonProp = ({ "stroke": dataItem.outline_color || "#000000", "stroke-width": "1" });

            overridePolygonProperties(polygons, layerId, polygonFill, polygonProp);
          } else {
            alert("Please, choose correct Data Type")
          }

          break

        case 'kml':
          alert("Please, choose correct Data Type")
          break
      }

      // hide and show markers' layers to turn on/off visible button in widget
      let findlayerId = dataStore.find(obj => obj.layerId === layerId);
      if (findlayerId && findlayerId.arr.length > 0) {
        if (dataItem.visible === true || dataItem.visible === undefined) {
          findlayerId.arr.forEach((element) => {
            let markerId = element;
            reearth.layers.show(markerId);
          });
        } else {
          findlayerId.arr.forEach((element) => {
            let markerId = element;
            reearth.layers.hide(markerId);
          });
        }
      }
    }
    //  ./overrideProperties


    function handleKMLFile(data) {
      //Handle KML file
      let parser = new DOMParser();
      let kmlDoc = parser.parseFromString(data, "application/xml");

      //Check valid href tag exist on data
      let hrefTags = kmlDoc.getElementsByTagName("href")
      if (hrefTags.length > 0) {
        for (let i = 0; i < hrefTags.length; i++) {
          if (!isValidUrl(hrefTags[i].textContent)) {
            let fixedURL = "https:" + hrefTags[i].textContent
            kmlDoc.getElementsByTagName("href")[i].textContent = fixedURL
          }
        }
      }

      let s = new XMLSerializer();
      let newXmlStr = s.serializeToString(kmlDoc);

      //Blob
      const blob = new Blob([newXmlStr], { type: 'text/xml;charset=utf-8;' });

      let result = URL.createObjectURL(blob);
      let geojson = toGeoJSON.kml(kmlDoc)
      let cameraHeight = Math.round(Math.sqrt(2 * (turf.area(turf.envelope(geojson)))))
      // console.log(cameraHeight);

      let center = turf.center(geojson);
      return {
        data: result,
        centerPoint: center,
        height: cameraHeight,
      }
    }
    //  ./handleKMLFile

    function isValidUrl(string) {
      try {
        new URL(string);
        return true;
      } catch (err) {
        return false;
      }
    }

  </script>
  `);

  reearth.on("update", send);
  send();

  function send() {
  reearth.ui.postMessage({
  property: reearth.widget.property,
  layer: reearth.layers.layers
  })
  }

  reearth.on("message", (msg) => {
  if (msg.type == "Properties") {
  reearth.layers.overrideProperty(msg.layerId, {
  default: {
  url: msg.geoJson,
  type: "geojson",
  },
  })
  }
  })