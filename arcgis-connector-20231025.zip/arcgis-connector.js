reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  :root {
    --brand-blue-main: #3B3CD0;
    --color-secondary-main: #4D5358;
    --color-secondary-weak: #343A3F;
    --neutral-color-palette-3: #F5F5F5;
    --color-outline-weakest: rgba(0, 0, 0, 0.25);
    --color-content-with-background: #FFFFFF;
    --color-content-main: #E0E0E0;
  }

  html,
  body {
    margin: 0;
    width: 312px;
  }

  #wrapper {
    position: relative;
    box-sizing: border-box;
    display: flex;
    flex-wrap: nowrap;
    padding: 12px;
    flex-direction: column;
    border-radius: 4px;
    background: var(--neutral-color-palette-3);
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  ._open {
    width: 312px;
    height: 100%;
  }

  ._expanded {
    width: 44px;
    height: 44px;
    overflow: hidden;
  }

  #logo {
    position: fixed;
    margin-right: 8px;
    width: 20px;
    height: 20px;
    background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 20 20" fill="none"><path d="M14.375 10.007C13.4334 10.0079 12.5171 10.3126 11.7625 10.8758L9.12499 8.23829C9.69483 7.48913 10.0023 6.57328 9.99999 5.63204C10.0025 4.64635 9.67199 3.68872 9.06216 2.91433C8.45232 2.13994 7.59885 1.59417 6.64006 1.36548C5.68127 1.13679 4.67334 1.23857 3.77963 1.65433C2.88592 2.07009 2.15879 2.77547 1.71609 3.65615C1.27339 4.53683 1.14105 5.5412 1.34053 6.50649C1.54001 7.47178 2.05962 8.34143 2.81514 8.97449C3.57066 9.60756 4.51782 9.96694 5.50312 9.9944C6.48843 10.0219 7.45413 9.71579 8.24374 9.12579L10.875 11.7633C10.2851 12.5527 9.97907 13.5181 10.0063 14.5031C10.0336 15.4882 10.3926 16.4352 11.0253 17.1907C11.6579 17.9462 12.527 18.4661 13.492 18.666C14.4569 18.866 15.4611 18.7343 16.3418 18.2924C17.2226 17.8504 17.9283 17.1241 18.3448 16.231C18.7612 15.3379 18.864 14.3303 18.6364 13.3715C18.4088 12.4128 17.8642 11.5589 17.0907 10.9483C16.3173 10.3376 15.3604 10.006 14.375 10.007V10.007ZM2.49999 5.63204C2.49999 5.01397 2.68327 4.40978 3.02665 3.89588C3.37003 3.38198 3.85809 2.98144 4.42911 2.74491C5.00012 2.50839 5.62846 2.4465 6.23465 2.56708C6.84084 2.68766 7.39766 2.98529 7.8347 3.42233C8.27174 3.85937 8.56937 4.41619 8.68995 5.02238C8.81052 5.62857 8.74864 6.2569 8.51212 6.82792C8.27559 7.39894 7.87505 7.887 7.36115 8.23038C6.84724 8.57376 6.24306 8.75704 5.62499 8.75704C4.79619 8.75704 4.00133 8.4278 3.41528 7.84175C2.82923 7.25569 2.49999 6.46084 2.49999 5.63204V5.63204Z" fill="%233B3CD0"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
    cursor: pointer;
  }

  .title {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
  }

  #plugin-title {
    color: var(--brand-blue-main);
    text-align: center;
    margin: 4px 0 4px 30px;
    font-family: 'Roboto';
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 100%;
    text-wrap: nowrap;
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  #close {
    width: 20px;
    height: 20px;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M15.625 4.375L4.375 15.625" stroke="%23595959" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.625 15.625L4.375 4.375" stroke="%23595959" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
    cursor: pointer;
  }

  .layer-list__wrap {
    display: flex;
    align-items: center;
    flex-direction: row;
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
    margin: 12px 4px 0 4px;
    border-bottom: 1px solid var(--color-outline-weakest);
  }

  #layer-list__logo {
    width: 16px;
    height: 16px;
    margin-right: 8px;
  }
  .layer-list__logo svg{
    fill: var(--brand-blue-main);
  }

  #layer-title {
    color: var(--color-secondary-main);
    font-family: 'Noto Sans';
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 22px;
    padding: 6px 2px;
    margin: 0;
  }

  .layer-list {
    display: flex;
    flex-direction: column;
    transition: all 0.3s cubic-bezier(0.93, 0.58, 0.58, 0.92);
  }

  .layer-list__item {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    color: var(--color-secondary-weak);
    text-align: center;
    font-family: 'Noto Sans';
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
  }

  .layer-list__item:last-of-type {
    margin-bottom: 0;
  }

  .layer-list__item:hover {
    background: var(--color-content-with-background);
  }

  .item-title__wrap {
    display: flex;
    flex-direction: row;
    width: 100%;
    align-items: center;
    text-align: center;
    padding: 5px 12px;
    background: inherit;
    border: none;
    cursor: pointer;
  }

  .item-marker {
    width: 20px;
    height: 20px;
    margin-right: 6px;
  }

  ._default {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 4C7.50555 4 7.0222 4.14662 6.61107 4.42133C6.19995 4.69603 5.87952 5.08648 5.6903 5.54329C5.50108 6.00011 5.45157 6.50277 5.54804 6.98773C5.6445 7.47268 5.8826 7.91814 6.23223 8.26777C6.58186 8.6174 7.02732 8.8555 7.51227 8.95196C7.99723 9.04843 8.49989 8.99892 8.95671 8.8097C9.41352 8.62048 9.80397 8.30005 10.0787 7.88893C10.3534 7.4778 10.5 6.99445 10.5 6.5C10.5 5.83696 10.2366 5.20107 9.76777 4.73223C9.29893 4.26339 8.66304 4 8 4ZM8 8C7.70333 8 7.41332 7.91203 7.16664 7.7472C6.91997 7.58238 6.72771 7.34811 6.61418 7.07403C6.50065 6.79994 6.47094 6.49834 6.52882 6.20736C6.5867 5.91639 6.72956 5.64912 6.93934 5.43934C7.14912 5.22956 7.41639 5.0867 7.70736 5.02882C7.99834 4.97094 8.29994 5.00065 8.57403 5.11418C8.84811 5.22771 9.08238 5.41997 9.2472 5.66664C9.41203 5.91332 9.5 6.20333 9.5 6.5C9.5 6.89782 9.34196 7.27936 9.06066 7.56066C8.77936 7.84196 8.39782 8 8 8ZM8 1C6.54182 1.00165 5.14383 1.58165 4.11274 2.61274C3.08165 3.64383 2.50165 5.04182 2.5 6.5C2.5 8.4625 3.40688 10.5425 5.125 12.5156C5.89701 13.4072 6.76591 14.2101 7.71562 14.9094C7.7997 14.9683 7.89985 14.9999 8.0025 14.9999C8.10515 14.9999 8.20531 14.9683 8.28938 14.9094C9.23734 14.2098 10.1046 13.4069 10.875 12.5156C12.5906 10.5425 13.5 8.4625 13.5 6.5C13.4983 5.04182 12.9184 3.64383 11.8873 2.61274C10.8562 1.58165 9.45818 1.00165 8 1ZM8 13.875C6.96688 13.0625 3.5 10.0781 3.5 6.5C3.5 5.30653 3.97411 4.16193 4.81802 3.31802C5.66193 2.47411 6.80653 2 8 2C9.19347 2 10.3381 2.47411 11.182 3.31802C12.0259 4.16193 12.5 5.30653 12.5 6.5C12.5 10.0769 9.03312 13.0625 8 13.875Z" fill="%23343A3F"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }

  ._line {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><g clip-path="url(%23clip0_1817_8710)"><circle cx="1.99996" cy="1.99935" r="1.33333" fill="%23343A3F"/><ellipse cx="12.6667" cy="3.99935" rx="1.33333" ry="1.33333" fill="%23343A3F"/><ellipse cx="14" cy="10.6673" rx="1.33333" ry="1.33333" fill="%23343A3F"/><ellipse cx="1.99996" cy="13.9993" rx="1.33333" ry="1.33333" fill="%23343A3F"/><path fill-rule="evenodd" clip-rule="evenodd" d="M12.2426 4.42845L1.90789 2.49068L2.09218 1.50781L13.0908 3.57005L14.5814 11.0233L2.13385 14.481L1.86621 13.5175L13.4186 10.3085L12.2426 4.42845Z" fill="%23343A3F"/></g><defs><clipPath id="clip0_1817_8710"><rect width="16" height="16" fill="white"/></clipPath></defs></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }

  ._polygon {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><g clip-path="url(%23clip0_1817_8715)"><circle cx="1.99996" cy="1.99935" r="1.33333" fill="%23343A3F"/><ellipse cx="12.6667" cy="3.99935" rx="1.33333" ry="1.33333" fill="%23343A3F"/><ellipse cx="14" cy="10.6673" rx="1.33333" ry="1.33333" fill="%23343A3F"/><ellipse cx="1.99996" cy="13.9993" rx="1.33333" ry="1.33333" fill="%23343A3F"/><path fill-rule="evenodd" clip-rule="evenodd" d="M1.5 1.39844L13.0907 3.5717L14.5814 11.025L1.5 14.6587V1.39844ZM2.5 2.60336V13.3431L13.4186 10.3101L12.2426 4.4301L2.5 2.60336Z" fill="%23343A3F"/><path fill-rule="evenodd" clip-rule="evenodd" d="M13.0087 4.3643L2.34202 14.3643L1.65808 13.6348L12.3247 3.63477L13.0087 4.3643Z" fill="%23343A3F"/></g><defs><clipPath id="clip0_1817_8715"><rect width="16" height="16" fill="white"/></clipPath></defs></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }

  ._kml {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.13816 0.861366C9.01751 0.740671 8.85081 0.666016 8.66667 0.666016H4C2.89543 0.666016 2 1.56145 2 2.66602V13.3327C2 14.4373 2.89543 15.3327 4 15.3327H12C13.1046 15.3327 14 14.4373 14 13.3327V5.99935C14 5.63116 13.7015 5.33268 13.3333 5.33268H11.7239L9.33333 2.94216V1.33268C9.33333 1.14863 9.25875 0.982002 9.13816 0.861366ZM8 1.99935H4C3.63181 1.99935 3.33333 2.29783 3.33333 2.66602V13.3327C3.33333 13.7009 3.63181 13.9993 4 13.9993H12C12.3682 13.9993 12.6667 13.7009 12.6667 13.3327V6.66602" fill="%23343A3F"/><path fill-rule="evenodd" clip-rule="evenodd" d="M9.13807 0.861278C9.01305 0.736254 8.84348 0.666016 8.66667 0.666016H4C2.89543 0.666016 2 1.56145 2 2.66602V13.3327C2 14.4373 2.89543 15.3327 4 15.3327H12C13.1046 15.3327 14 14.4373 14 13.3327V5.99935C14 5.82254 13.9298 5.65297 13.8047 5.52794L9.13807 0.861278ZM4 1.99935H8.39052L12.6667 6.27549V13.3327C12.6667 13.7009 12.3682 13.9993 12 13.9993H4C3.63181 13.9993 3.33333 13.7009 3.33333 13.3327V2.66602C3.33333 2.29783 3.63181 1.99935 4 1.99935Z" fill="%23343A3F"/><path d="M9.33333 1.33268C9.33333 0.964492 9.03486 0.666016 8.66667 0.666016C8.29848 0.666016 8 0.964492 8 1.33268V5.99935C8 6.36754 8.29848 6.66602 8.66667 6.66602H13.3333C13.7015 6.66602 14 6.36754 14 5.99935C14 5.63116 13.7015 5.33268 13.3333 5.33268H9.33333V1.33268Z" fill="%23343A3F"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }


  .item-eye {
    width: 20px;
    height: 20px;
    border: none;
    padding: 4px 20px;
    -webkit-transition-duration: 0.2s;
    -o-transition-duration: 0.2s;
    transition-duration: 0.2s;
    cursor: pointer;
  }

  ._show {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.596224 6.80498C0.339978 7.20175 0.164094 7.51443 0.0703819 7.70186C-0.0234606 7.88954 -0.0234606 8.11046 0.0703819 8.29814C0.164094 8.48557 0.339978 8.79825 0.596224 9.19502C1.02033 9.8517 1.52075 10.508 2.09698 11.1226C3.7742 12.9117 5.7468 14 8 14C10.2532 14 12.2258 12.9117 13.903 11.1226C14.4792 10.508 14.9797 9.8517 15.4038 9.19502C15.66 8.79825 15.8359 8.48557 15.9296 8.29814C16.0235 8.11046 16.0235 7.88954 15.9296 7.70186C15.8359 7.51443 15.66 7.20175 15.4038 6.80498C14.9797 6.1483 14.4792 5.49201 13.903 4.87737C12.2258 3.08833 10.2532 2 8 2C5.7468 2 3.7742 3.08833 2.09698 4.87737C1.52075 5.49201 1.02033 6.1483 0.596224 6.80498ZM3.06973 10.2107C2.5522 9.65868 2.09949 9.06496 1.71631 8.47165C1.60755 8.30325 1.5111 8.14509 1.42718 8C1.5111 7.85491 1.60755 7.69675 1.71631 7.52835C2.09949 6.93504 2.5522 6.34132 3.06973 5.78929C4.5175 4.24501 6.16991 3.33333 8.00004 3.33333C9.83017 3.33333 11.4826 4.24501 12.9303 5.78929C13.4479 6.34132 13.9006 6.93504 14.2838 7.52835C14.3925 7.69675 14.489 7.85491 14.5729 8C14.489 8.14509 14.3925 8.30325 14.2838 8.47165C13.9006 9.06496 13.4479 9.65868 12.9303 10.2107C11.4826 11.755 9.83017 12.6667 8.00004 12.6667C6.16991 12.6667 4.5175 11.755 3.06973 10.2107ZM8 10.6667C6.52724 10.6667 5.33333 9.47276 5.33333 8C5.33333 6.52724 6.52724 5.33333 8 5.33333C9.47276 5.33333 10.6667 6.52724 10.6667 8C10.6667 9.47276 9.47276 10.6667 8 10.6667ZM9.33333 8C9.33333 8.73638 8.73638 9.33333 8 9.33333C7.26362 9.33333 6.66667 8.73638 6.66667 8C6.66667 7.26362 7.26362 6.66667 8 6.66667C8.73638 6.66667 9.33333 7.26362 9.33333 8Z" fill="%23343A3F"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }

  ._hide {
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 2.5L13 13.5" stroke="%23343A3F" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.68167 9.85012C9.19105 10.2961 8.54337 10.5289 7.88112 10.4973C7.21886 10.4657 6.59627 10.1724 6.15028 9.6818C5.70429 9.19121 5.47144 8.54356 5.50295 7.8813C5.53446 7.21904 5.82774 6.59642 6.31828 6.15039" stroke="%23343A3F" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.62465 4.28711C2.07657 5.57746 1 8.00001 1 8.00001C1 8.00001 3 12.4995 8 12.4995C9.1715 12.5089 10.3284 12.239 11.3748 11.7124" stroke="%23343A3F" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.0381 10.5692C14.4007 9.34876 15 8.0005 15 8.0005C15 8.0005 13 3.50001 8.00004 3.50001C7.56699 3.4993 7.13463 3.53451 6.7074 3.60527" stroke="%23343A3F" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.47046 5.54492C9.00182 5.64695 9.48577 5.91852 9.84972 6.31888C10.2137 6.71924 10.438 7.22682 10.4891 7.76547" stroke="%23343A3F" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>');
    background-repeat: no-repeat;
    background-position: center center;
  }
</style>
<div id="wrapper" class="_open">
  <div class="title">
    <div id="logo">
    </div>
    <p id="plugin-title">ArcGIS connector</p>
    <div id="close"></div>
  </div>
  <div class="layer-list__wrap">
    <div id="layer-list__logo">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.76284 8.94024C7.83565 8.97961 7.91711 9.00023 7.99989 9.00024C8.08266 9.00023 8.16413 8.97961 8.23694 8.94024L14.7369 5.44024C14.8164 5.39742 14.8828 5.3339 14.9291 5.2564C14.9753 5.1789 14.9998 5.09032 14.9998 5.00006C14.9998 4.9098 14.9753 4.82122 14.9291 4.74372C14.8828 4.66623 14.8164 4.6027 14.7369 4.55989L8.23694 1.05989C8.16411 1.02058 8.08265 1 7.99989 1C7.91713 1 7.83567 1.02058 7.76284 1.05989L1.26284 4.55989C1.18338 4.6027 1.11698 4.66623 1.07071 4.74372C1.02443 4.82122 1 4.9098 1 5.00006C1 5.09032 1.02443 5.1789 1.07071 5.2564C1.11698 5.3339 1.18338 5.39742 1.26284 5.44024L7.76284 8.94024ZM7.99989 7.93239L2.55459 5.00024L7.99989 2.06814L13.4452 5.00024L7.99989 7.93239ZM7.99987 12.0003C7.91709 12.0003 7.83563 11.9797 7.76282 11.9403L1.26282 8.4403L1.73692 7.5603L7.99987 10.9325L14.2628 7.5603L14.7369 8.44065L8.23692 11.9407C8.16408 11.9799 8.08261 12.0004 7.99987 12.0003ZM7.99987 15.0003C7.91709 15.0003 7.83563 14.9797 7.76282 14.9403L1.26282 11.4403L1.73692 10.5603L7.99987 13.9325L14.2628 10.5603L14.7369 11.4407L8.23692 14.9407C8.16408 14.9799 8.08261 15.0004 7.99987 15.0003Z"/>
      </svg>
    </div>
    <p id="layer-title">Layer list</p>
  </div>
  <input type="hidden" id="data-store" />
  <div id="layer-list" class="layer-list">

  </div>

  <script src="https://unpkg.com/togeojson@0.16.0/togeojson.js"></script>
  <script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
  <script>

document.getElementById("layer-list__logo").querySelector("svg").querySelector("path").setAttribute("fill", "var(--color-secondary-weak)");

// dark theme
// document.getElementById("layer-list__logo").querySelector("svg").querySelector("path").setAttribute("fill", "var(--color-content-main)");

    let reearth;
    let property;
    let layers;
    let newProperty;
    let itemEyeID = "itemEye_ID__";

    let startTime = new Date();

    // expireIn indicate token validity period. 60 is for debugging. It should be 7000 in actual operation.
    const expireIn = 60;

    let dataStore = [];
    dataStore.push({
      itemId: "",
      layerId: "",
      arr: [],
      centerPoint: [],
      cameraHeight: [],
    });

    let iconCoords = Array();


    let API_URL
    let ARCGIS_URL
    let client_id
    let client_secret


    let TokenURL = 'https://www.arcgis.com/sharing/rest/oauth2/token'
    let token_url
    let token = "";
    let param = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-Esri-Authorization': ""
    };

    let wrapper = document.getElementById('wrapper');
    let layersTitle = document.getElementById('layer-title')
    let layerList = document.getElementById("layer-list");
    let pluginTitle = document.getElementById("plugin-title");

    document.getElementById('close').addEventListener('click', expand);
    function expand() {
      wrapper.classList.remove("_open");
      wrapper.classList.add("_expanded");
      layersTitle.style.opacity = "0";
      pluginTitle.style.opacity = "0";
    }

    document.getElementById('logo').addEventListener('click', handleWrapper);
    function handleWrapper() {
      wrapper.classList.add("_open");
      wrapper.classList.remove("_expanded");
      layersTitle.style.opacity = "1";
      pluginTitle.style.opacity = "1";
    }


    // Get different between two json object
    function getObjectDiff(obj1, obj2) {
      let diff = {};
      if (obj1 && obj2) {
        // Check for keys in obj1 that are not in obj2
        for (let key in obj1) {
          if (!obj2.hasOwnProperty(key)) {
            diff[key] = [obj1[key], undefined];
          }
        }
        // Check for keys in obj2 that are not in obj1
        for (let key in obj2) {
          if (!obj1.hasOwnProperty(key)) {
            diff[key] = [undefined, obj2[key]];
          }
        }
        // Check for keys in both objects
        for (let key in obj1) {
          if (obj2.hasOwnProperty(key)) {
            if (typeof obj1[key] === 'object') {
              diff[key] = getObjectDiff(obj1[key], obj2[key]);
            } else if (obj1[key] !== obj2[key]) {
              diff[key] = [obj1[key], obj2[key]];
            }
          }
        }
      }

      return diff;
    }
    let oldProperties

    function setProperties(pro) {
      API_URL = pro.client_data.URL;
      ARCGIS_URL = pro.client_data.arcgis_URL;
      client_id = pro.client_data.client_ID;
      client_secret = pro.client_data.client_secret;

      token_url = TokenURL + "?client_id=" + client_id + "&grant_type=client_credentials&client_secret=" + client_secret;

      hideLayers(pro.data_list);

    }
    //  ./setProperties

    window.addEventListener("message", async function (e) {
      if (e.source !== parent) return;
      reearth = e.source.reearth;
      layers = reearth.layers.layers;


      let diff = getObjectDiff(property, e.data.property)
      // console.log("diff: ", diff)
      if (JSON.stringify(diff) === "{}") {
        // console.log("first time call getToken()")
        setProperties(e.data.property)

        get_token().then(() => {
          handleData(e.data.property);
        });
      } else if (diff.hasOwnProperty("client_data") && (
        diff.client_data.hasOwnProperty("client_ID") ||
        diff.client_data.hasOwnProperty("client_secret") ||
        diff.client_data.hasOwnProperty("URL") ||
        diff.client_data.hasOwnProperty("arcgis_URL"))) {
        // console.log("get new token and handle get token() when change client_data")
        setProperties(e.data.property)
        get_token().then(() => {
          handleData(e.data.property);
        });
      }
      else {
        // console.log("Just handle data_list()");
        hideLayers(e.data.property.data_list)
        handleData(e.data.property);
      }

      property = e.data.property;
    });
    //  ./ window.addEventListener


    async function get_token() {
      return new Promise((resolve, reject) => {
        fetch(token_url)
          .then(function (response) {
            if (response.ok) {
              return response.json();
            } else {
              throw new Error("Could not reach the API: " + response.statusText);
            }
          })
          .then(function (data) {
            token = "Bearer " + data['access_token'];
            param['X-Esri-Authorization'] = token;
            // console.log(token);
            resolve(); // Resolve the Promise when token retrieval is successful
          })
          .catch(function (error) {
            console.error(error);
            reject(error); // Reject the Promise if there's an error
          });
      });
    }

    // hide layers if item deleted from Data List
    function hideLayers(list) {
      if (!list || 0 === list.length) {
        let filteredLayers = layers.filter(layer => layer.id)
        filteredLayers.forEach(layer => {
          reearth.layers.hide(layer.id)
          let layerId = layer.id;

        })
      } else {
        const list_id = list.map(obj => obj.id);
        let filteredLayers = layers.filter(layer => !list_id.includes(layer.id));
        filteredLayers.forEach(layer => {
          reearth.layers.hide(layer.id)
          let layerId = layer.id;
        });
      }
    }

    function download(itemID, dataItem) {
      let itemElm = document.getElementById(itemID)
      let dataType = itemElm.getAttribute("data-type")

      let currentTime = new Date();
      let timeDiff = (currentTime.getTime() - startTime.getTime()) / 1000;
      if (timeDiff > expireIn) {
        console.log("token is expiered!");
        get_token();
        // console.log("get new token");
        startTime = new Date();
      }
      fetch(API_URL, {
        method: 'POST',
        headers: param,
        body: JSON.stringify({ "id": itemID, "arcgis_url": ARCGIS_URL })
      }).then(function (response) {
        if (response.ok) {
          if (dataType == "kml") {
            return response.text();
          } else {
            return response.json();
          }
        } else {
          throw new Error("Could not reach the API" + response.statusText);
        }
      }).then(function (data) {
        if (!data.hasOwnProperty("errorMessage")) {
          if (dataType == "kml") {
            let result = handleKMLFile(data)
            // console.log("kml result", result);
            showGeojson(result.data, result.centerPoint, result.height, itemID, dataType, dataItem)
          } else {
            let geojsonData = data;
            // console.log("geojsonData", geojsonData);
            let center = turf.center(geojsonData);
            let height = 50000
            showGeojson(geojsonData, center, height, itemID, dataType, dataItem)
          }
        } else {
          //Show error
          if (data.errorType == "Function.ResponseSizeTooLarge") {
            alert("File size is too large")
          } else {
            // console.log(data)
          }
        }
      }).catch(function (error) {
        console.log(error)
        //Hide the layer if exist
        let found = dataStore.some(obj => obj.itemId == itemID)
        if (found) {
          reearth.layers.hide(itemID)
        }
      });
    }

    // handle data from ArcGis create ui blocks
    function handleData(files) {
      // remove remove sample of ui for layer-list and create new one with items 
      document.getElementById("layer-list").remove();
      let layerList = document.createElement('div');
      layerList.classList.add("layer-list");
      layerList.id = "layer-list";
      document.getElementById('wrapper').appendChild(layerList);

      let dataList = files.data_list;

      i = 0;
      // create items for layer list
      dataList.forEach(dataItem => {

        if (dataItem.layer_name && dataItem.symbol_ID) {
          i++

          let layerName = dataItem.layer_name;
          let itemID = dataItem.symbol_ID;

          let layerList__item = document.createElement('div');
          layerList__item.classList.add('layer-list__item');

          let itemTitle__wrap = document.createElement('button');
          itemTitle__wrap.classList.add('item-title__wrap');
          itemTitle__wrap.id = itemID;
          itemTitle__wrap.setAttribute("data-type", dataItem.data_type);
          let dataType = itemTitle__wrap.getAttribute("data-type")
          console.log(dataType);

          let itemMarker = document.createElement('div');
          itemMarker.classList.add('item-marker');
          switch (dataType) {
            case "kml": 
            itemMarker.classList.add('_kml');
              break;

              case "line": 
              itemMarker.classList.add('_line');
              break;

              case "polygon": 
              itemMarker.classList.add('_polygon');
              break;

            default:
            itemMarker.classList.add('_default');
              break;
          }

          // if (dataType = "default" || "undefind" || "point" || "icon"){
          //   itemMarker.classList.add('_default');
          // } else if (dataType = "line"){
          //   itemMarker.classList.remove('_default');
          //   itemMarker.classList.add('_line');
          // } else if (dataType = "polygon"){
          //   itemMarker.classList.remove('_default');
          //   itemMarker.classList.add('_polygon');
          // } else if((dataType = "kml")){
          //   itemMarker.classList.remove('_default');
          //   itemMarker.classList.add('_kml');
          // }

          let itemTitle = document.createElement('div');
          itemTitle.classList.add('item-title');
          itemTitle.id = "itemTitle__" + i;
          itemTitle.textContent = layerName;

          let itemEye = document.createElement('button');
          itemEye.classList.add('item-eye');
          itemEyeID = itemEyeID + i;
          itemEye.id = itemEyeID;
          itemEye.classList.add('_show');

          layerList.appendChild(layerList__item);
          layerList__item.appendChild(itemTitle__wrap);
          itemTitle__wrap.appendChild(itemMarker);
          itemTitle__wrap.appendChild(itemTitle);
          layerList__item.appendChild(itemEye);

          //  push to dataStore item id for each item from layer list, as layer list created every time new, needs some date to store them 
          let found = dataStore.some(obj => obj.itemId == itemID)
          if (!found) {
            dataStore.push({ itemId: itemID, layerId: "", arr: [], centerPoint: [], cameraHeight: [], })
            download(itemID, dataItem);
          } else {
            // if item created push to dataStore layer Id
            let findItemId = dataStore.find(obj => obj.itemId === itemID)
            let layerId = findItemId.layerId;
            layerList__item.id = layerId;

            // hide and show layers turn on/off visible button in widget
            if (dataItem.visible === true || dataItem.visible === undefined) {
              itemEye.classList.remove('_hide');
              itemEye.classList.add('_show');
              reearth.layers.show(layerId);
            } else {
              itemEye.classList.remove('_show');
              itemEye.classList.add('_hide');
              reearth.layers.hide(layerId);
            }

            if (layerId && dataItem.data_type !== "default" && dataItem.data_type !== "kml") {
              // getting layer Id and data type to override properties, if file already downloaded
              let geoJsonData = reearth.layers.findById(layerId).property.default.url;

              if (geoJsonData.type == "FeatureCollection") {
                overrideProperties(geoJsonData, dataItem, layerId);
              }

              reearth.layers.overrideProperty(layerId, {
                default: {
                  clampToGround: dataItem.clampToGround,
                },
              })

            }
          }

          document.getElementById('data-store').setAttribute('data-store', JSON.stringify(dataStore));

          // move camera if click ui button
          itemTitle__wrap.addEventListener("click", moveCamera);
          function moveCamera() {
            let layerId = itemTitle__wrap.parentElement.id
            let file = reearth.layers.findById(layerId).property.default.url;

            let findItemId = dataStore.find(obj => obj.itemId == itemID);
            let center = findItemId.centerPoint;
            let cameraHeight = findItemId.cameraHeight;

            // console.log("center", center);
            // console.log("cameraHeight", cameraHeight);

            reearth.camera.flyTo({
              lat: center[1],
              lng: center[0],
              height: cameraHeight || 50000,
            }, {
              duration: 2
            });
          }
        }
      });
      //   ./forEach

      // hide and show layers by clicking one eye button (ui)
      eye_btns = document.querySelectorAll('.item-eye');

      let handleLayer = e => {
        let layer_id = e.target.parentElement.id;
        reearth.layers.layers;

        var btnClass = e.target.classList;

        if (btnClass.contains('_show')) {
          reearth.layers.hide(layer_id);

          let findlayerId = dataStore.find(obj => obj.layerId === layer_id);
          if (findlayerId.arr.length > 0) {
            findlayerId.arr.forEach((element) => {
              let markerId = element;
              reearth.layers.hide(markerId);
            });
          }
          btnClass.remove('_show');
          btnClass.add('_hide');

        } else {
          reearth.layers.show(layer_id);

          let findlayerId = dataStore.find(obj => obj.layerId === layer_id);
          if (findlayerId.arr.length > 0) {
            findlayerId.arr.forEach((element) => {
              let markerId = element;
              reearth.layers.show(markerId);
            });
          }
          btnClass.remove('_hide');
          btnClass.add('_show');

        }
      }

      for (let eye_btn of eye_btns) {
        eye_btn.addEventListener("click", handleLayer);
      }
      //  ./hide and show layers by clicking one eye button (ui)

    };
    //  ./handleData

    let geojsonLayerId
    function showGeojson(data, center, height, itemID, dataType, dataItem) {

      let findItemId = dataStore.find(obj => obj.itemId == itemID);
      let centerPoint = center.geometry.coordinates
      findItemId.centerPoint = centerPoint;

      let cameraHeight = height;
      // console.log(cameraHeight);
      let geoJson = turf.featureCollection([]);
      let url;


      if ((data.type == "FeatureCollection")) {

        let multiPolygon = turf.featureCollection([]);
        let poly = turf.featureCollection([]);
        let lines = turf.featureCollection([]);
        let points = turf.featureCollection([]);
        let multiPoints = turf.featureCollection([]);

        let polygonProp = ({ "stroke": "#000000", "stroke-width": "1" });

        // MultiPolygon and Polygon are rewriting to prevent a bug with a data visualization
        for (let i = 0; i < data.features.length; i++) {
          if (data.features[i].geometry.type == "MultiPolygon") {
            multiPolygon.features.push(data.features[i])
          } else if (data.features[i].geometry.type == "Polygon") {
            poly.features.push(data.features[i])
          }
        }

        turf.featureEach(multiPolygon, function (currentFeature) {
          let multipoligonCoords = turf.getCoords(currentFeature);
          multipoligonCoords.forEach((e) => {
            let line = turf.multiLineString(turf.getCoords(e));
            line.properties = polygonProp;
            data.features.push(line);
          })
        });

        turf.featureEach(poly, function (currentFeature) {
          currentFeature.properties["stroke-width"] = 0;
          let linestring = turf.lineString(turf.getCoords(currentFeature)[0])
          linestring.properties["stroke"] = "#000000";
          data.features.push(linestring);
        })

        // for publishing project with correct data type dividing and rewrited properties
        for (let i = 0; i < data.features.length; i++) {
          if ((data.features[i].geometry.type == "LineString") || (data.features[i].geometry.type == "MultiLineString")) {
            lines.features.push(data.features[i]);
          } else if (data.features[i].geometry.type === "Point") {
            points.features.push(data.features[i]);
          } else if (data.features[i].geometry.type === "MultiPoint") {
            multiPoints.features.push(data.features[i]);
          }
        }

        // transform lines and points to Polygons and counting area of every Polygons
        let area = (turf.area(multiPolygon)) + (turf.area(poly) * 2) || 0;
        let linesLength = turf.area(turf.bboxPolygon(turf.bbox(lines))) || 0;
        let pointsArea = turf.area(turf.envelope(points)) || 0;
        let multipointsArea = turf.area(turf.envelope(multiPoints)) || 0;
        let pointsLength = pointsArea + multipointsArea;

        // count math square to get diagonal with formula d = √2a this will be the height for camera
        cameraHeight = Math.round(Math.sqrt(2 * (area + linesLength + pointsLength)));

        findItemId.cameraHeight = cameraHeight;

        // console.log("area: ", area);
        // console.log("linesLength: ", linesLength);
        // console.log("pointsLength: ", pointsLength);
        // console.log("cameraHeight: ", cameraHeight);


        switch (dataType) {

          case "point":
            let options = { steps: 20, units: 'meters' };
            var circle;
            var border;

            let strokeProp = ({ "stroke": dataItem.point_outline_color || "#000000", "stroke-width": dataItem.point_outline_width || "2" });
            let radius = dataItem.point_size || "1500";
            let pointFill = dataItem.point_color || "yellow";

            turf.featureEach(multiPoints, function (currentFeature, featureIndex) {
              let multipoints = turf.getCoords(currentFeature);
              multipoints.forEach((el) => {
                let center = turf.getCoords(el);
                circle = turf.circle(center, radius, options);
                circle.properties["fill"] = pointFill;

                border = turf.polygonToLine(circle);
                border.properties = strokeProp;
                geoJson.features.push(circle);
                geoJson.features.push(border);
              })
            });

            turf.featureEach(points, function (currentFeature, featureIndex) {
              let center = turf.getCoord(currentFeature);
              circle = turf.circle(center, radius, options);
              circle.properties["fill"] = pointFill;

              border = turf.polygonToLine(circle);
              border.properties = strokeProp;
              geoJson.features.push(circle);
              geoJson.features.push(border);
            });

            // 
            dataType = "geojson"
            url = geoJson
            break;

          case "icon":
            dataType = "geojson"

            let iconCoords = Array();
            let imageUrl = dataItem.image_URL
            let imageSize = dataItem.image_size || "1";

            multiPoints.features.map((element) => {
              let multipoints = turf.getCoords(element);
              multipoints.forEach((el) => {
                let coord = turf.getCoord(el);
                iconCoords.push(coord);
                let geometry = ({ "name": "markers", "coordinates": coord });
                geoJson.features.push(turf.feature(geometry));
              })
            })

            points.features.map((element) => {
              let coord = element.geometry.coordinates
              iconCoords.push(coord);
              let geometry = ({ "name": "markers", "coordinates": coord });
              geoJson.features.push(turf.feature(geometry));
            })

            iconCoords.forEach((element) => {

              let long = element[0];
              let lat = element[1];

              let markerId = reearth.layers.add({
                extensionId: "marker",
                isVisible: true,
                title: "marker",
                property: {
                  default: {
                    image: imageUrl,
                    imageSize: imageSize,
                    heightReference: "clamp",
                    location: {
                      lat: lat,
                      lng: long,
                    },
                  }
                }
              });

              let findItemId = dataStore.find(obj => obj.itemId == itemID)
              if (findItemId) {
                findItemId.arr.push(markerId);
              }
            })

            url = geoJson
            break;

          case "line":

            let lineProp = ({ "stroke": dataItem.line_color, "stroke-width": dataItem.line_width || "1" });

            lines.features.forEach((line) => {
              line.properties = lineProp;
              geoJson.features.push(line);
            })
            url = geoJson
            dataType = "geojson"
            break;

          case "polygon":
            // getting properties data from widget (dataItem... ) and implement them to the features properties
            let polygonProp = ({ "stroke": dataItem.outline_color, "stroke-width": "1", });

            turf.featureEach(multiPolygon, function (currentFeature) {
              currentFeature.properties["fill"] = dataItem.polygon_color;
              geoJson.features.push(currentFeature);
              let multipoligonCoords = turf.getCoords(currentFeature);
              multipoligonCoords.forEach((e) => {
                let line = turf.multiLineString(turf.getCoords(e));
                line.properties = polygonProp;
                geoJson.features.push(line);
              })
            });

            turf.featureEach(poly, function (currentFeature) {
              currentFeature.properties["fill"] = dataItem.polygon_color;
              currentFeature.properties["stroke-width"] = 0;
              geoJson.features.push(currentFeature);
              let linestring = turf.lineString(turf.getCoords(currentFeature)[0])
              linestring.properties["stroke"] = dataItem.outline_color;
              geoJson.features.push(linestring);
            })

            url = geoJson;
            dataType = "geojson"
            break;

          default:
            dataType = "geojson"
            url = data
            break;
        }
      } else {
        dataType = "kml"
        url = data;
      }

      findItemId.cameraHeight = cameraHeight;
      // upload geojson or kml file
      geojsonLayerId = reearth.layers.add({
        extensionId: "resource",
        isVisible: true,
        title: dataType,
        property: {
          default: {
            url: url,
            type: dataType,
            clampToGround: dataItem.clampToGround,
          },
        },
      })

      reearth.camera.flyTo({
        lat: center.geometry.coordinates[1],
        lng: center.geometry.coordinates[0],
        height: cameraHeight || 50000,
      }, {
        duration: 2
      });

      // push layer id to dataStore
      findItemId.layerId = geojsonLayerId;

      document.getElementById(itemID).parentElement.setAttribute('id', geojsonLayerId)
    };
    //  ./showGeojson


    // override properties from default point marker or icon to circle
    function overridePoinProperties(points, layerId, strokeProp, radius, pointFill) {

      let geoJson = turf.featureCollection([]);
      var center;
      var options = { steps: 20, units: 'meters' };
      var circle;
      var line;
      let multipoints;

      points.features.map((element) => {
        if (element.geometry.type == "MultiPoint") {
          turf.featureEach(points, function (currentFeature, featureIndex) {

            multipoints = turf.getCoords(currentFeature);
            multipoints.forEach((el) => {
              center = turf.getCoords(el);
              circle = turf.circle(center, radius, options);
              circle.properties["fill"] = pointFill;

              line = turf.polygonToLine(circle);
              line.properties = strokeProp;

              geoJson.features.push(circle);
              geoJson.features.push(line);
            })
          });

        } else if (element.geometry.type == "Point") {

          turf.featureEach(points, function (currentFeature, featureIndex) {

            center = turf.getCoord(currentFeature);
            circle = turf.circle(center, radius, options);
            circle.properties["fill"] = pointFill;

            line = turf.polygonToLine(circle);
            line.properties = strokeProp;
            geoJson.features.push(circle);
            geoJson.features.push(line);
          });

        } else if (element.geometry.name === "markers") {
          let coords = element.geometry.coordinates;
          circle = turf.circle(coords, radius, options);
          circle.properties["fill"] = pointFill;

          line = turf.polygonToLine(circle);
          line.properties = strokeProp;
          geoJson.features.push(circle);
          geoJson.features.push(line);
        }
      });

      parent.postMessage({ type: "Properties", layerId, geoJson }, "*");
    }
    //  ./overridePoinProperties

    // override properties from default point marker or circle to icon
    function overrideIconProperties(iconCoords, layerId, imageUrl, imageSize) {

      let findlayerId = dataStore.find(obj => obj.layerId === layerId)
      if (findlayerId.arr.length == 0) {

        iconCoords.forEach((element) => {

          let long = element[0];
          let lat = element[1];

          let markerId = reearth.layers.add({
            extensionId: "marker",
            isVisible: true,
            title: "marker",
            property: {
              default: {
                image: imageUrl,
                imageSize: imageSize,
                heightReference: "clamp",
                location: {
                  lat: lat,
                  lng: long,
                },
              }
            }
          });
          reearth.layers.show(markerId);
          let findlayerId = dataStore.find(obj => obj.layerId === layerId)
          if (findlayerId) {
            findlayerId.arr.push(markerId);
          }
        })
      } else {
        findlayerId.arr.forEach((element) => {
          let markerId = element;
          reearth.layers.show(markerId);
          reearth.layers.overrideProperty((markerId), {
            default: {
              image: imageUrl,
              imageSize: imageSize,
            }
          });
        });
      }

    }
    //  ./overrideIconProperties


    function overrideLineProperties(lines, layerId, lineProp) {

      let geoJson = turf.featureCollection([]);

      lines.features.forEach((line) => {
        line.properties = lineProp;
        geoJson.features.push(line);
      })
      parent.postMessage({ type: "Properties", layerId, geoJson }, "*");
    }
    //  ./overrideLineProperties

    function overridePolygonProperties(polygons, layerId, polygonFill, polygonProp) {

      let lineString
      let geoJson = turf.featureCollection([]);
      let multi = turf.featureCollection([]);
      let poly = turf.featureCollection([]);

      for (let i = 0; i < polygons.features.length; i++) {
        if (polygons.features[i].geometry.type == "MultiPolygon") {
          multi.features.push(polygons.features[i])
        } else {
          poly.features.push(polygons.features[i])
        }
      }

      turf.featureEach(multi, function (currentFeature) {
        currentFeature.properties["fill"] = polygonFill;
        let multipoligonCoords = turf.getCoords(currentFeature);
        multipoligonCoords.forEach((e) => {
          let line = turf.multiLineString(turf.getCoords(e));
          line.properties = polygonProp;
          geoJson.features.push(currentFeature);
          geoJson.features.push(line);
        })
      });

      turf.featureEach(poly, function (currentFeature, featureIndex) {
        currentFeature.properties["fill"] = polygonFill;
        currentFeature.properties["stroke-width"] = 0;
        linestring = turf.lineString(turf.getCoords(currentFeature)[0])
        linestring.properties["stroke"] = polygonProp.stroke
        geoJson.features.push(currentFeature);
        geoJson.features.push(linestring);

      })

      parent.postMessage({ type: "Properties", layerId, geoJson }, "*");
    }
    //  ./overridePolygonProperties


    // getting properties from widget and override them
    function overrideProperties(geoJsonData, dataItem, layerId) {
let icon = document.getElementById(layerId).querySelector('.item-marker')


      let dataType = dataItem.data_type
      let isInvalid = false;

      let lines = turf.featureCollection([]);
      let points = turf.featureCollection([]);
      let polygons = turf.featureCollection([]);

      // sort features by type
      for (let i = 0; i < geoJsonData.features.length; i++) {
        if ((geoJsonData.features[i].geometry.type === "Point") || (geoJsonData.features[i].geometry.type === "MultiPoint") || (geoJsonData.features[i].geometry.name === "markers")) {
          points.features.push(geoJsonData.features[i]);
        } else if ((geoJsonData.features[i].geometry.type === "LineString") || (geoJsonData.features[i].geometry.type === "MultiLineString")) {
          lines.features.push(geoJsonData.features[i]);
        } else if ((geoJsonData.features[i].geometry.type === "Polygon") || (geoJsonData.features[i].geometry.type === "MultiPolygon")) {
          polygons.features.push(geoJsonData.features[i]);
        }
      }

      switch (dataType) {
        case 'point':
        console.log();
        icon.classList.add("_default");
          isInvalid = false;
          if (points.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {

            let findlayerId = dataStore.find(obj => obj.layerId === layerId);
            if (findlayerId && findlayerId.arr.length > 0) {
              findlayerId.arr.forEach((element) => {
                let markerId = element;
                reearth.layers.overrideProperty((markerId), {
                  default: {
                    image: [],
                    imageSize: 0,
                  }
                });

              });
            }


            let strokeProp = ({ "stroke": dataItem.point_outline_color || "#000000", "stroke-width": dataItem.point_outline_width || "3" });
            let radius = dataItem.point_size || "1500";
            let pointFill = dataItem.point_color || "yellow";

            overridePoinProperties(points, layerId, strokeProp, radius, pointFill);
          } else {
            alert("Please, choose correct Data Type")
          }

          break

        case 'icon':
        icon.classList.add("_default");

          iconCoords = Array()
          isInvalid = false;
          let coord;

          if (points.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {

            let imageUrl = dataItem.image_URL
            let imageSize = dataItem.image_size || "1";

            points.features.map((element) => {
              if (element.geometry.type == "MultiPoint") {
                multipoints = turf.getCoords(element);
                multipoints.forEach((el) => {
                  coord = turf.getCoord(el);
                  iconCoords.push(coord);
                })
              } else if ((element.geometry.type == "Point") || (element.geometry.name === "markers")) {
                coord = element.geometry.coordinates
                iconCoords.push(coord);
              }
            })

            overrideIconProperties(iconCoords, layerId, imageUrl, imageSize);

            let geoJson = turf.featureCollection([]);
            parent.postMessage({ type: "Properties", layerId, geoJson }, "*");

          } else {
            alert("Please, choose correct Data Type")
          }
          break

        case 'line':
        icon.classList.add("_line");
          isInvalid = false;

          if (lines.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {
            let findlayerId = dataStore.find(obj => obj.layerId === layerId);
            if (findlayerId && findlayerId.arr.length > 0) {
              findlayerId.arr.forEach((element) => {
                let markerId = element;
                reearth.layers.overrideProperty((markerId), {
                  default: {
                    image: [],
                    imageSize: 0,
                  }
                });
              });
            }

            let lineProp = ({ "stroke": dataItem.line_color || "yellow", "stroke-width": dataItem.line_width || "1" });

            overrideLineProperties(lines, layerId, lineProp);
          } else {
            alert("Please, choose correct Data Type")
          }
          break

        case 'polygon':
        icon.classList.add("_polygon");
          isInvalid = false;

          if (polygons.features.length === 0) {
            isInvalid = true
          }

          if (!isInvalid) {
            let findlayerId = dataStore.find(obj => obj.layerId === layerId);
            if (findlayerId && findlayerId.arr.length > 0) {
              findlayerId.arr.forEach((element) => {
                let markerId = element;
                // reearth.layers.hide(markerId);
                reearth.layers.overrideProperty((markerId), {
                  default: {
                    image: [],
                    imageSize: 0,
                  }
                });
              });
            }
            let polygonFill = dataItem.polygon_color || "yellow";
            let polygonProp = ({ "stroke": dataItem.outline_color || "#000000", "stroke-width": "1" });

            overridePolygonProperties(polygons, layerId, polygonFill, polygonProp);
          } else {
            alert("Please, choose correct Data Type")
          }

          break

        case 'kml':
          alert("Please, choose correct Data Type")
          break
      }

      // hide and show markers' layers to turn on/off visible button in widget
      let findlayerId = dataStore.find(obj => obj.layerId === layerId);
      if (findlayerId && findlayerId.arr.length > 0) {
        if (dataItem.visible === true || dataItem.visible === undefined) {
          findlayerId.arr.forEach((element) => {
            let markerId = element;
            reearth.layers.show(markerId);
          });
        } else {
          findlayerId.arr.forEach((element) => {
            let markerId = element;
            reearth.layers.hide(markerId);
          });
        }
      }
    }
    //  ./overrideProperties


    function handleKMLFile(data) {
      //Handle KML file
      let parser = new DOMParser();
      let kmlDoc = parser.parseFromString(data, "application/xml");

      //Check valid href tag exist on data
      let hrefTags = kmlDoc.getElementsByTagName("href")
      if (hrefTags.length > 0) {
        for (let i = 0; i < hrefTags.length; i++) {
          if (!isValidUrl(hrefTags[i].textContent)) {
            let fixedURL = "https:" + hrefTags[i].textContent
            kmlDoc.getElementsByTagName("href")[i].textContent = fixedURL
          }
        }
      }

      let s = new XMLSerializer();
      let newXmlStr = s.serializeToString(kmlDoc);

      //Blob
      const blob = new Blob([newXmlStr], { type: 'text/xml;charset=utf-8;' });

      let result = URL.createObjectURL(blob);
      let geojson = toGeoJSON.kml(kmlDoc)
      let cameraHeight = Math.round(Math.sqrt(2 * (turf.area(turf.envelope(geojson)))))
      // console.log(cameraHeight);

      let center = turf.center(geojson);
      return {
        data: result,
        centerPoint: center,
        height: cameraHeight,
      }
    }
    //  ./handleKMLFile

    function isValidUrl(string) {
      try {
        new URL(string);
        return true;
      } catch (err) {
        return false;
      }
    }

  </script>
  `);

  reearth.on("update", send);
  send();

  function send() {
  reearth.ui.postMessage({
  property: reearth.widget.property,
  layer: reearth.layers.layers
  })
  }

  reearth.on("message", (msg) => {
  if (msg.type == "Properties") {
  reearth.layers.overrideProperty(msg.layerId, {
  default: {
  url: msg.geoJson,
  type: "geojson",
  },
  })
  }
  })